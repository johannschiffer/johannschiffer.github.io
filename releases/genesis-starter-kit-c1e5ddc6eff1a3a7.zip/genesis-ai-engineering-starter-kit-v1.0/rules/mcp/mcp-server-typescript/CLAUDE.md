# CLAUDE.md: MCP servers in TypeScript

## Project context
This project uses: Node 20+, @modelcontextprotocol/sdk, Zod, stdio and streamable HTTP.

## Conventions
- Define each tool with a Zod schema and a descriptive title and description
- Keep tools idempotent where possible and say so in the description
- Handle errors by returning isError results with actionable messages instead of throwing across the transport
- Write logs to stderr; keep stdout clean for stdio

## How to verify your work
- Integration-test with the SDK's in-memory transport pair

## Security requirements
- Validate all arguments, scope filesystem and network access to explicit allowlists

## Do not
- console.log in stdio servers
- Overly broad tools such as run_anything
- Returning megabytes of text

## Workflow
1. Restate the task in one sentence and list the files you expect to touch.
2. Implement in small steps; run the relevant tests after each step.
3. Summarise what changed, what you verified, and what remains uncertain.
