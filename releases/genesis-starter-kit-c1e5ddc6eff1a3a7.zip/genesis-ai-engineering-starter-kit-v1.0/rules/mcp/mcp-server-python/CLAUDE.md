# CLAUDE.md: MCP servers in Python

## Project context
This project uses: Python 3.10+, FastMCP or the official mcp SDK, Pydantic, stdio and SSE transports.

## Conventions
- One tool = one clear verb with a precise docstring; the docstring is the model-facing contract
- Type every parameter; validate and bound inputs (max lengths, enums) before use
- Return structured, minimal results; paginate and truncate large outputs to protect the model context
- Log to stderr only on stdio transports; stdout belongs to the protocol
- Make destructive tools opt-in with explicit confirmation parameters and dry-run modes

## How to verify your work
- Test tools as plain functions, plus one end-to-end test through the real transport

## Security requirements
- Authenticate SSE endpoints (Bearer), validate Origin, rate-limit, and never expose arbitrary shell or file access

## Do not
- print() to stdout in stdio servers
- Tools that accept free-form SQL or shell strings
- Unbounded result sizes

## Workflow
1. Restate the task in one sentence and list the files you expect to touch.
2. Implement in small steps; run the relevant tests after each step.
3. Summarise what changed, what you verified, and what remains uncertain.
