# CLAUDE.md: Secrets management

## Project context
This project uses: Vault, cloud secret managers, SOPS, pre-commit gitleaks.

## Conventions
- Secrets come from the environment or a secret manager, never from the repository
- Rotate on a schedule and immediately after exposure; design code to reload without redeploy
- Use scoped, short-lived credentials (OIDC, IAM roles) over static keys
- Run gitleaks or trufflehog in pre-commit and CI

## How to verify your work
- Test that the app fails closed when a secret is missing

## Security requirements
- Redact secrets in logs, traces and error reports

## Do not
- .env files committed
- Secrets in command-line arguments
- One shared credential for all environments

## Workflow
1. Restate the task in one sentence and list the files you expect to touch.
2. Implement in small steps; run the relevant tests after each step.
3. Summarise what changed, what you verified, and what remains uncertain.
