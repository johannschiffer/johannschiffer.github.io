# CLAUDE.md: API security (OWASP API Top 10)

## Project context
This project uses: REST/GraphQL APIs, OAuth2/OIDC, JWT, rate limiting.

## Conventions
- Object-level and function-level authorisation checked server-side on every request
- Short-lived access tokens, rotating refresh tokens, verify iss, aud, exp and algorithm
- Rate limit per identity and per IP; cap payload sizes and pagination limits
- Return generic auth errors; no stack traces or internal ids in responses

## How to verify your work
- Include negative authorisation tests: user A must not reach user B's objects

## Security requirements
- Disable verbose errors in production, inventory every endpoint, retire old API versions

## Do not
- Trusting client-supplied roles or ids
- Mass assignment from raw request bodies
- JWT alg=none or shared-secret reuse

## Workflow
1. Restate the task in one sentence and list the files you expect to touch.
2. Implement in small steps; run the relevant tests after each step.
3. Summarise what changed, what you verified, and what remains uncertain.
