# CLAUDE.md: Security-focused code review

## Project context
This project uses: OWASP ASVS, CWE Top 25, semgrep, bandit or gosec.

## Conventions
- Trace every untrusted input to its sinks: SQL, shell, filesystem, templates, deserialisers, redirects
- Check authentication, then authorisation on every object access (IDOR)
- Look for secrets in code, logs and error messages
- Report findings with severity, exploit scenario, affected lines and a concrete fix

## How to verify your work
- Reproduce each finding with a failing test or proof-of-concept before reporting it

## Security requirements
- Prefer allowlists; treat deserialisation, XML and template rendering as high risk

## Do not
- Reporting theoretical issues without a path to exploitation
- Suggesting fixes that only hide the symptom

## Workflow
1. Restate the task in one sentence and list the files you expect to touch.
2. Implement in small steps; run the relevant tests after each step.
3. Summarise what changed, what you verified, and what remains uncertain.
