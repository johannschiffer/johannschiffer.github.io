# CLAUDE.md: Python data pipelines

## Project context
This project uses: Python 3.11+, pandas or polars, pydantic, SQLite or Postgres, structured logging.

## Conventions
- Every stage is a pure function from typed input to typed output; side effects live at the edges
- Make stages idempotent: re-running with the same input produces the same output and no duplicates
- Validate data at stage boundaries with Pydantic or pandera and fail loudly on schema drift
- Persist checkpoints so a failed run resumes instead of restarting

## How to verify your work
- Keep a tiny golden dataset in tests/fixtures and snapshot expected outputs

## Security requirements
- Never log raw records that may contain PII; log counts and ids

## Do not
- Mutating input DataFrames in place
- Silent type coercion
- Reading whole files into memory when streaming works

## Workflow
1. Restate the task in one sentence and list the files you expect to touch.
2. Implement in small steps; run the relevant tests after each step.
3. Summarise what changed, what you verified, and what remains uncertain.
