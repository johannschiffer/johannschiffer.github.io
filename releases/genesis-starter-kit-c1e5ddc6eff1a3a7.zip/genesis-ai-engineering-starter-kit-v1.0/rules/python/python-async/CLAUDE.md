# CLAUDE.md: Python asyncio concurrency

## Project context
This project uses: Python 3.11+, asyncio TaskGroup, anyio, httpx.AsyncClient, aiosqlite.

## Conventions
- Use asyncio.TaskGroup for structured concurrency; never fire-and-forget create_task without keeping a reference
- Every outbound call has an explicit timeout (asyncio.timeout or httpx.Timeout)
- Bound concurrency with asyncio.Semaphore; never gather an unbounded list
- Offload CPU work with run_in_executor or a process pool

## How to verify your work
- Use pytest-asyncio in auto mode; test cancellation and timeout paths explicitly

## Security requirements
- Treat cancellation as normal: always release locks and connections in finally blocks

## Do not
- Calling asyncio.run inside a running loop
- Mixing threads and loops without call_soon_threadsafe
- Swallowing CancelledError

## Workflow
1. Restate the task in one sentence and list the files you expect to touch.
2. Implement in small steps; run the relevant tests after each step.
3. Summarise what changed, what you verified, and what remains uncertain.
