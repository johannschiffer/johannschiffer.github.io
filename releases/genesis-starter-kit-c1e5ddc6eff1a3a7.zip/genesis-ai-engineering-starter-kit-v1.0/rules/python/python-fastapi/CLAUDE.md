# CLAUDE.md: Python / FastAPI services

## Project context
This project uses: Python 3.11+, FastAPI, Pydantic v2, SQLAlchemy 2.0 async, uvicorn, pytest.

## Conventions
- Type-annotate every function; run mypy --strict on app/ in CI
- One APIRouter per domain module; keep route handlers under 25 lines and push logic into service functions
- Request and response bodies are Pydantic models; never return ORM objects directly
- Inject DB sessions, settings and auth via Depends; no module-level global clients
- Raise HTTPException only in the API layer; services raise domain exceptions mapped by exception handlers

## How to verify your work
- pytest with httpx.AsyncClient against the ASGI app, no live server
- Override dependencies in tests instead of monkeypatching
- Every endpoint gets a success test, a validation-failure test and an auth-failure test

## Security requirements
- Validate all input with Pydantic constraints (max_length, ge, le, regex)
- Hash passwords with argon2 or bcrypt; compare tokens with hmac.compare_digest
- Set explicit CORS origins; never allow_origins=['*'] with credentials

## Do not
- Blocking calls (requests, time.sleep, sync DB drivers) inside async def
- Catch-all except Exception that swallows errors
- Business logic in route functions

## Workflow
1. Restate the task in one sentence and list the files you expect to touch.
2. Implement in small steps; run the relevant tests after each step.
3. Summarise what changed, what you verified, and what remains uncertain.
