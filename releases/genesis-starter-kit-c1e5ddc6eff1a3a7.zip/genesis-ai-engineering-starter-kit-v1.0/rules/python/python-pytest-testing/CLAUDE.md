# CLAUDE.md: Python testing with pytest

## Project context
This project uses: pytest, pytest-cov, hypothesis, freezegun, responses or respx.

## Conventions
- Arrange / Act / Assert with one behaviour per test; name tests test_<unit>_<condition>_<result>
- Use fixtures for setup; keep conftest.py fixtures small and composable
- Parametrize instead of copy-pasting similar tests
- Use tmp_path for files and monkeypatch for env vars

## How to verify your work
- Target 90% branch coverage on core modules, but treat coverage as a floor, not a goal
- Property-test parsers and serializers with hypothesis
- Mark slow or network tests and exclude them from the default run

## Security requirements
- Never commit real credentials in fixtures; generate fake ones
- Block outbound network in unit tests (respx / responses with assert_all_called)

## Do not
- Tests that depend on execution order
- Sleeping to wait for async work
- Asserting on log text instead of behaviour

## Workflow
1. Restate the task in one sentence and list the files you expect to touch.
2. Implement in small steps; run the relevant tests after each step.
3. Summarise what changed, what you verified, and what remains uncertain.
