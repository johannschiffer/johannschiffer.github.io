# CLAUDE.md: Rust web services with Axum

## Project context
This project uses: Rust stable, axum, tokio, sqlx, tower, serde, tracing.

## Conventions
- Share state through axum State with Arc; keep handlers thin and typed with extractors
- Return IntoResponse errors from a single AppError enum
- sqlx compile-time checked queries and migrations in migrations/
- Apply tower layers for timeouts, tracing, compression and request limits

## How to verify your work
- Use tower::ServiceExt::oneshot to test routers without a socket

## Security requirements
- Validate extractor input, cap body sizes, and never log secrets

## Do not
- Holding a MutexGuard across .await
- Blocking the runtime with sync IO
- unwrap in handlers

## Workflow
1. Restate the task in one sentence and list the files you expect to touch.
2. Implement in small steps; run the relevant tests after each step.
3. Summarise what changed, what you verified, and what remains uncertain.
