# CLAUDE.md: Rust command-line tools

## Project context
This project uses: Rust stable, clap derive, anyhow, thiserror, tracing, assert_cmd.

## Conventions
- Library crate for logic, thin binary crate for argument parsing and exit codes
- thiserror for library errors, anyhow only in main
- Return Result everywhere; no unwrap or expect outside tests and provably infallible spots
- Machine-readable output behind --json; human output to stdout, diagnostics to stderr

## How to verify your work
- assert_cmd and tempfile for end-to-end CLI tests; proptest for parsers

## Security requirements
- Canonicalise and validate user-supplied paths before touching the filesystem

## Do not
- Cloning to appease the borrow checker without thinking
- Panics for expected failures
- Global mutable state

## Workflow
1. Restate the task in one sentence and list the files you expect to touch.
2. Implement in small steps; run the relevant tests after each step.
3. Summarise what changed, what you verified, and what remains uncertain.
