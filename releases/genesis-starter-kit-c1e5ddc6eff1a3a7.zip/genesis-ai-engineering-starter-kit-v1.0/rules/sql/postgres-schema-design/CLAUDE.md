# CLAUDE.md: PostgreSQL schema design

## Project context
This project uses: PostgreSQL 15+, SQL migrations, pgcrypto, citext.

## Conventions
- Every table has a primary key; prefer bigint identity or uuid v7
- Model constraints in the database: NOT NULL, CHECK, UNIQUE, foreign keys with explicit ON DELETE
- Use timestamptz, never timestamp; store money as integer minor units or numeric
- Name things consistently: snake_case, singular tables, <table>_id foreign keys

## How to verify your work
- Test constraints with deliberate bad inserts in a migration test suite

## Security requirements
- Least-privilege roles: app role cannot DDL; read-only role for analytics
- Row-level security for multi-tenant tables

## Do not
- JSON columns for relational data
- Nullable columns by default
- Storing secrets or tokens in plaintext

## Workflow
1. Restate the task in one sentence and list the files you expect to touch.
2. Implement in small steps; run the relevant tests after each step.
3. Summarise what changed, what you verified, and what remains uncertain.
