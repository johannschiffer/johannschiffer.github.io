# CLAUDE.md: Safe SQL migrations

## Project context
This project uses: Alembic, Flyway, golang-migrate or sqitch; PostgreSQL.

## Conventions
- Expand, migrate, contract: add nullable column, backfill in batches, enforce constraint, drop the old one in a later release
- CREATE INDEX CONCURRENTLY and ADD CONSTRAINT ... NOT VALID then VALIDATE
- Set lock_timeout in every migration so a blocked DDL fails fast
- Every migration is reviewed with its rollback or forward-fix plan

## How to verify your work
- Run migrations against a restored copy of production schema in CI

## Security requirements
- Never run destructive DDL without a verified backup

## Do not
- ALTER TABLE ... ADD COLUMN with volatile default on huge tables (pre-PG11 behaviour assumptions)
- Mixing schema and large data changes in one transaction
- Editing an applied migration

## Workflow
1. Restate the task in one sentence and list the files you expect to touch.
2. Implement in small steps; run the relevant tests after each step.
3. Summarise what changed, what you verified, and what remains uncertain.
