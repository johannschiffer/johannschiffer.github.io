# CLAUDE.md: PostgreSQL query performance

## Project context
This project uses: PostgreSQL 15+, EXPLAIN (ANALYZE, BUFFERS), pg_stat_statements.

## Conventions
- Read the plan before adding an index: EXPLAIN (ANALYZE, BUFFERS) on production-sized data
- Index foreign keys and filter columns; use partial and covering indexes where selectivity justifies them
- Keyset pagination instead of OFFSET on large tables
- Avoid SELECT *; select the columns you need

## How to verify your work
- Benchmark with realistic row counts and compare plans before and after

## Security requirements
- Set statement_timeout and lock_timeout for application roles

## Do not
- N+1 queries from ORMs
- Functions on indexed columns in WHERE
- Long transactions held open

## Workflow
1. Restate the task in one sentence and list the files you expect to touch.
2. Implement in small steps; run the relevant tests after each step.
3. Summarise what changed, what you verified, and what remains uncertain.
