# CLAUDE.md: TypeScript library authoring

## Project context
This project uses: TypeScript strict, tsup or unbuild, vitest, changesets, ESM + CJS exports.

## Conventions
- Public API is explicit: export only from src/index.ts and document each export with TSDoc
- Ship ESM and CJS with a correct exports map and bundled .d.ts
- Zero runtime dependencies unless justified in the PR
- Semver strictly; record every user-visible change with a changeset

## How to verify your work
- Type-level tests with expectTypeOf for public generics

## Security requirements
- Audit dependencies in CI and pin the lockfile

## Do not
- Default exports
- Leaking internal types in the public surface
- Breaking changes in minor versions

## Workflow
1. Restate the task in one sentence and list the files you expect to touch.
2. Implement in small steps; run the relevant tests after each step.
3. Summarise what changed, what you verified, and what remains uncertain.
