# CLAUDE.md: Next.js (App Router)

## Project context
This project uses: Next.js 14+, React 18+, TypeScript strict, Server Components, Zod, Tailwind.

## Conventions
- Server Components by default; add 'use client' only for state, effects or browser APIs, and keep client islands small
- Fetch data in Server Components or route handlers; cache and revalidate deliberately with tags
- Mutations go through Server Actions or route handlers with Zod validation
- Colocate loading.tsx, error.tsx and not-found.tsx with each route segment

## How to verify your work
- Vitest or Jest for units, Playwright for critical flows, MSW for network mocking

## Security requirements
- Validate every Server Action input server-side; never trust the client
- Only NEXT_PUBLIC_ variables reach the browser; keep secrets server-only

## Do not
- useEffect for data fetching
- Passing non-serializable props across the server/client boundary
- any and non-null assertions to silence the compiler

## Workflow
1. Restate the task in one sentence and list the files you expect to touch.
2. Implement in small steps; run the relevant tests after each step.
3. Summarise what changed, what you verified, and what remains uncertain.
