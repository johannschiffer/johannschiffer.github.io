# CLAUDE.md: React + TypeScript components

## Project context
This project uses: React 18+, TypeScript strict, React Query, React Testing Library.

## Conventions
- Function components and hooks only; props typed with explicit interfaces
- Derive state instead of syncing it; lift state only as far as needed
- Server state belongs in React Query, not useState plus useEffect
- Every list item has a stable key; every interactive element is a real button or link

## How to verify your work
- Test behaviour through the DOM with Testing Library; query by role and label, not test ids first

## Security requirements
- Never use dangerouslySetInnerHTML with unsanitised input

## Do not
- Index as key on reorderable lists
- Prop drilling beyond two levels instead of composition or context
- Giant components over 200 lines

## Workflow
1. Restate the task in one sentence and list the files you expect to touch.
2. Implement in small steps; run the relevant tests after each step.
3. Summarise what changed, what you verified, and what remains uncertain.
