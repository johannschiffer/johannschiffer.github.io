# CLAUDE.md: Node.js / Express APIs

## Project context
This project uses: Node 20+, Express or Fastify, TypeScript strict, Zod, pino, vitest.

## Conventions
- Layers: routes -> controllers -> services -> repositories; no SQL in controllers
- Validate req.body, params and query with Zod middleware
- Centralised error middleware returns a consistent JSON error shape
- Use pino structured logging with a request id on every line

## How to verify your work
- supertest against the app instance; mock only external services

## Security requirements
- helmet, rate limiting and strict body size limits by default
- Parameterised queries only; never string-build SQL

## Do not
- Unhandled promise rejections
- Callback-style code mixed with async/await
- process.env read outside a single config module

## Workflow
1. Restate the task in one sentence and list the files you expect to touch.
2. Implement in small steps; run the relevant tests after each step.
3. Summarise what changed, what you verified, and what remains uncertain.
