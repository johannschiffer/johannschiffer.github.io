# CLAUDE.md: Production Dockerfiles

## Project context
This project uses: Docker, BuildKit, multi-stage builds, distroless or slim bases.

## Conventions
- Multi-stage builds: compile in a builder stage, copy artefacts into a minimal runtime stage
- Pin base images by version and digest; rebuild on a schedule for patches
- Run as a non-root user with a read-only root filesystem where possible
- Add a HEALTHCHECK and handle SIGTERM for graceful shutdown
- Order layers for cache: dependency manifests first, source last; keep a tight .dockerignore

## How to verify your work
- Build in CI, run container-structure-test or a smoke test against the built image

## Security requirements
- Scan images with trivy or grype; never bake secrets into layers, use BuildKit secrets

## Do not
- :latest tags
- apt-get install without --no-install-recommends and cache cleanup
- Running as root

## Workflow
1. Restate the task in one sentence and list the files you expect to touch.
2. Implement in small steps; run the relevant tests after each step.
3. Summarise what changed, what you verified, and what remains uncertain.
