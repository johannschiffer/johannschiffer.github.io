# CLAUDE.md: Kubernetes manifests

## Project context
This project uses: Kubernetes 1.28+, Kustomize or Helm, probes, resource limits.

## Conventions
- Every container declares requests and limits, readiness and liveness probes
- Use Deployments with RollingUpdate, PodDisruptionBudgets and topology spread for HA
- Configuration in ConfigMaps, secrets in a secret manager synced to Secrets
- Label consistently with app.kubernetes.io/* labels

## How to verify your work
- Validate with kubeconform and kube-linter in CI

## Security requirements
- runAsNonRoot, readOnlyRootFilesystem, drop all capabilities, default-deny NetworkPolicy

## Do not
- Latest tags
- hostPath volumes
- Privileged containers

## Workflow
1. Restate the task in one sentence and list the files you expect to touch.
2. Implement in small steps; run the relevant tests after each step.
3. Summarise what changed, what you verified, and what remains uncertain.
