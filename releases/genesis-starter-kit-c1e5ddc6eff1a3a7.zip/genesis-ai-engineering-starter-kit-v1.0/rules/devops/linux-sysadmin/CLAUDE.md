# CLAUDE.md: Linux administration

## Project context
This project uses: systemd, journald, ufw or nftables, SSH, cron/systemd timers.

## Conventions
- Manage services with systemd units; set Restart=on-failure, hardening flags (NoNewPrivileges, ProtectSystem)
- Prefer systemd timers over cron for logging and failure visibility
- Key-only SSH, no root login, fail2ban or equivalent
- Log to journald; rotate and cap size

## How to verify your work
- Test changes on a disposable VM or container first; keep a rollback path

## Security requirements
- Principle of least privilege with sudoers drop-ins; audit open ports with ss -tulpn

## Do not
- chmod 777
- Editing live configs without a backup
- Running services as root

## Workflow
1. Restate the task in one sentence and list the files you expect to touch.
2. Implement in small steps; run the relevant tests after each step.
3. Summarise what changed, what you verified, and what remains uncertain.
