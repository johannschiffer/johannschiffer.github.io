# CLAUDE.md: GitHub Actions CI/CD

## Project context
This project uses: GitHub Actions, reusable workflows, OIDC, matrix builds.

## Conventions
- Pin third-party actions by commit SHA; grant minimum permissions: at job level
- Cache dependencies with the official cache or setup-* actions
- Use matrices for supported runtime versions; fail fast off for diagnostics
- Deploy with OIDC federation instead of long-lived cloud keys

## How to verify your work
- Run lint, type-check and tests as separate jobs so failures are obvious

## Security requirements
- Never echo secrets; never run untrusted PR code with pull_request_target and secrets

## Do not
- curl | bash installs
- Workflow-wide write-all permissions
- Skipping tests on main

## Workflow
1. Restate the task in one sentence and list the files you expect to touch.
2. Implement in small steps; run the relevant tests after each step.
3. Summarise what changed, what you verified, and what remains uncertain.
