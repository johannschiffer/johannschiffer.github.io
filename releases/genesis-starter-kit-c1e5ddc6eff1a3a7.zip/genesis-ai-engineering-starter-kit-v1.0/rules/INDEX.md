# Ruleset index

| Stack | Category | .cursorrules | CLAUDE.md |
|---|---|---|---|
| Python / FastAPI services | Python | `python/python-fastapi/.cursorrules` | `python/python-fastapi/CLAUDE.md` |
| Python testing with pytest | Python | `python/python-pytest-testing/.cursorrules` | `python/python-pytest-testing/CLAUDE.md` |
| Python asyncio concurrency | Python | `python/python-async/.cursorrules` | `python/python-async/CLAUDE.md` |
| Python data pipelines | Python | `python/python-data-pipelines/.cursorrules` | `python/python-data-pipelines/CLAUDE.md` |
| Next.js (App Router) | TypeScript | `typescript/nextjs-app-router/.cursorrules` | `typescript/nextjs-app-router/CLAUDE.md` |
| React + TypeScript components | TypeScript | `typescript/react-typescript/.cursorrules` | `typescript/react-typescript/CLAUDE.md` |
| Node.js / Express APIs | TypeScript | `typescript/node-express-api/.cursorrules` | `typescript/node-express-api/CLAUDE.md` |
| TypeScript library authoring | TypeScript | `typescript/typescript-library/.cursorrules` | `typescript/typescript-library/CLAUDE.md` |
| Rust command-line tools | Rust | `rust/rust-cli/.cursorrules` | `rust/rust-cli/CLAUDE.md` |
| Rust web services with Axum | Rust | `rust/rust-axum-service/.cursorrules` | `rust/rust-axum-service/CLAUDE.md` |
| Go HTTP services | Go | `go/go-http-service/.cursorrules` | `go/go-http-service/CLAUDE.md` |
| Go command-line tools | Go | `go/go-cli/.cursorrules` | `go/go-cli/CLAUDE.md` |
| PostgreSQL schema design | SQL | `sql/postgres-schema-design/.cursorrules` | `sql/postgres-schema-design/CLAUDE.md` |
| PostgreSQL query performance | SQL | `sql/postgres-performance/.cursorrules` | `sql/postgres-performance/CLAUDE.md` |
| Safe SQL migrations | SQL | `sql/sql-migrations/.cursorrules` | `sql/sql-migrations/CLAUDE.md` |
| Production Dockerfiles | DevOps | `devops/docker-production/.cursorrules` | `devops/docker-production/CLAUDE.md` |
| GitHub Actions CI/CD | DevOps | `devops/github-actions-ci/.cursorrules` | `devops/github-actions-ci/CLAUDE.md` |
| Kubernetes manifests | DevOps | `devops/kubernetes-basics/.cursorrules` | `devops/kubernetes-basics/CLAUDE.md` |
| Linux administration | DevOps | `devops/linux-sysadmin/.cursorrules` | `devops/linux-sysadmin/CLAUDE.md` |
| Security-focused code review | Security | `security/security-code-review/.cursorrules` | `security/security-code-review/CLAUDE.md` |
| API security (OWASP API Top 10) | Security | `security/owasp-api-security/.cursorrules` | `security/owasp-api-security/CLAUDE.md` |
| Secrets management | Security | `security/secrets-management/.cursorrules` | `security/secrets-management/CLAUDE.md` |
| MCP servers in Python | MCP | `mcp/mcp-server-python/.cursorrules` | `mcp/mcp-server-python/CLAUDE.md` |
| MCP servers in TypeScript | MCP | `mcp/mcp-server-typescript/.cursorrules` | `mcp/mcp-server-typescript/CLAUDE.md` |
| Agents that consume MCP servers | MCP | `mcp/mcp-client-agents/.cursorrules` | `mcp/mcp-client-agents/CLAUDE.md` |

Copy `.cursorrules` to your project root for Cursor, or `CLAUDE.md` for Claude Code. Combine files from several stacks by concatenating them and deleting duplicate sections.
