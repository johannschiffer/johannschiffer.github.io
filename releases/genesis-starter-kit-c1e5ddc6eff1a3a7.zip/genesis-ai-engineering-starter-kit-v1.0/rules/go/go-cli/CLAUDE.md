# CLAUDE.md: Go command-line tools

## Project context
This project uses: Go 1.22+, cobra or urfave/cli, slog, goreleaser.

## Conventions
- cmd/<name>/main.go only wires things; logic lives in internal/
- Exit non-zero on failure and print errors to stderr
- Config precedence: flags, environment, config file, defaults
- Cross-compile and release with goreleaser; embed version via ldflags

## How to verify your work
- Golden-file tests for output; run commands in-process via cobra's ExecuteC

## Security requirements
- Never echo secrets from flags or env; support reading secrets from files

## Do not
- os.Exit deep inside libraries
- init() side effects
- Reading stdin without checking for a TTY

## Workflow
1. Restate the task in one sentence and list the files you expect to touch.
2. Implement in small steps; run the relevant tests after each step.
3. Summarise what changed, what you verified, and what remains uncertain.
