# CLAUDE.md: Go HTTP services

## Project context
This project uses: Go 1.22+, net/http ServeMux, slog, sqlc or pgx, testify optional.

## Conventions
- Accept interfaces, return structs; define interfaces at the consumer
- Pass context.Context first in every function that does IO and honour cancellation
- Wrap errors with fmt.Errorf("...: %w") and test with errors.Is / errors.As
- Graceful shutdown with signal.NotifyContext and server.Shutdown

## How to verify your work
- Table-driven tests with t.Run, httptest.NewServer, go test -race ./... in CI

## Security requirements
- Set server timeouts (ReadHeaderTimeout at minimum) and limit request body with http.MaxBytesReader

## Do not
- Goroutines without an exit path
- Package-level mutable state
- panic for control flow

## Workflow
1. Restate the task in one sentence and list the files you expect to touch.
2. Implement in small steps; run the relevant tests after each step.
3. Summarise what changed, what you verified, and what remains uncertain.
