# MCP Architecture Playbook

A working guide to designing, securing and deploying Model Context Protocol servers.

## 1. What MCP gives you
MCP lets an AI client (Claude Desktop, Cursor, Windsurf, your own agent) call tools, read resources and use prompts exposed by a server process. The client decides *when* to call a tool; your server decides *what is possible*. Design the server so that the worst call an over-eager model can make is still acceptable.

## 2. Choose the transport
| Transport | Use when | Notes |
|---|---|---|
| stdio | Local tools launched by the client | stdout is the protocol channel: log to stderr only |
| SSE / streamable HTTP | Shared or remote servers | Needs auth (Bearer), Origin checks, TLS, rate limits |

Start with stdio. Move to HTTP only when several users or machines must share one server.

## 3. Tool design rules
1. **One verb per tool.** `query_readonly`, not `database`.
2. **The docstring is the contract.** The model reads it to decide when and how to call. State inputs, units, limits and side effects.
3. **Bound everything.** Max rows, max bytes, max seconds. Return `truncated: true` rather than megabytes of text.
4. **Return structure, not prose.** Small JSON objects with stable keys.
5. **Make danger explicit.** Destructive tools take `confirm: true` and support `dry_run`.
6. **Idempotent where possible.** Agents retry.

## 4. Security model
- Treat every tool argument as attacker-controlled: the model may be steered by prompt injection from web pages, emails or files it read.
- Allowlist paths, hosts and commands. Never expose a generic shell or raw SQL writer.
- Run with the least privilege: dedicated OS user, read-only database role, network egress limits.
- Authenticate remote transports with Bearer tokens, compare with constant-time functions, and rotate.
- Audit every call: caller, tool, argument hash, outcome, duration. Store it in SQLite WAL or your log pipeline.
- Keep secrets out of tool arguments and out of results.

## 5. Reliability
- Timeouts on every outbound call; exponential backoff with jitter for retries.
- Persist queues and receipts (SQLite WAL is enough for single-host servers).
- Structured JSON logs with a request id.
- Health endpoint or a cheap self-check command for container healthchecks.

## 6. Testing
- Unit-test tools as plain functions.
- One end-to-end test per server through the real transport.
- Negative tests: bad arguments, oversized inputs, missing auth, upstream timeouts.
- Replay recorded agent traces when you change tool descriptions; description changes alter model behaviour.

## 7. Deployment
- Local: `uvx --from git+https://github.com/johannschiffer/<server> <server>` and a client config entry (see `mcp-configs/`).
- Server: a small VPS is enough for most MCP workloads. Options: [Hetzner Cloud](https://www.hetzner.com/cloud), [DigitalOcean](https://www.digitalocean.com/).
- Scraping and browser servers usually need rotating proxies: [Webshare](https://www.webshare.io/), [ScraperAPI](https://www.scraperapi.com/), [Bright Data](https://brightdata.com/).
- Container: non-root user, pinned base image, healthcheck, read-only root filesystem.
- Some links above are referral links; they cost you nothing extra.

## 8. The six Genesis servers
| Server | Purpose |
|---|---|
| [CrawlEngine MCP](https://github.com/johannschiffer/crawlengine-mcp) | Anti-bot web scraping, clean Markdown, proxy rotation and TLS evasion |
| [BrowserBridge MCP](https://github.com/johannschiffer/browserbridge-mcp) | Deterministic headless browser automation with cryptographic action receipts |
| [PgSafe MCP](https://github.com/johannschiffer/pgsafe-mcp) | Zero-trust PostgreSQL/SQLite guard, live PII masking, zero-downtime migration checks |
| [OmniBridge MCP](https://github.com/johannschiffer/omnibridge-mcp) | Multi-channel notification and webhook bus with a persistent SQLite WAL queue |
| [SysFlow MCP](https://github.com/johannschiffer/sysflow-mcp) | Safe Linux administration plane: systemd, port audit, isolated execution |
| [FastMCP Forge](https://github.com/johannschiffer/fastmcp-forge) | Production MCP server scaffolder: stdio, SSE and auth middleware |

## 9. Go further
- Interactive config builder: https://johannschiffer.github.io
- Enterprise Suite (six Pro servers, Docker stack, 55 rulesets, 15 system prompts), $19: https://johanld.gumroad.com/l/tzuvz
