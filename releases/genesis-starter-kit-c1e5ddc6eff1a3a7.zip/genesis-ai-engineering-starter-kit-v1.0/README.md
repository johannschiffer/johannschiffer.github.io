# Genesis AI Engineering Starter Kit v1.0

> ### ⚡ Upgrade to Enterprise Suite Pro ($19 USD)
> | Capability | Starter Kit (Free / $0+) | Enterprise Suite Pro ($19 USD) |
> |---|---|---|
> | **Rulesets & Stack Blueprints** | 25 `.cursorrules` & `CLAUDE.md` files | 55+ Production Rulesets & 15 System Prompts |
> | **MCP Server Binaries** | 6 Public Lite CLI Tools | 6 Pro MCP Servers (Merged Modules + Test Suites) |
> | **Infrastructure & Orchestration** | Manual per-tool launch | Unified Docker Compose Stack (`docker-compose.genesis-stack.yml`) |
> | **Enterprise Proxy & DB Migration** | Community defaults | Rotating Residential Proxies & Zero-Downtime Migrations |
> | **License & Commercial Rights** | Personal / Evaluation | Full Commercial Lifetime License (`LICENSE-COMMERCIAL.txt`) |
> 
> [Upgrade to Genesis Enterprise Suite Pro ($19 USD)](https://johanld.gumroad.com/l/genesis-enterprise-suite) | [Interactive Web Config Generator](https://johannschiffer.github.io/)

---

## Contents
- `rules/`: 25 rulesets, each as `.cursorrules` and `CLAUDE.md` (see `rules/INDEX.md`).
- `mcp-configs/`: `claude_desktop_config.json`, `.cursor/mcp.json` and `generate_mcp_config.py` for the six Genesis MCP servers.
- `MCP_ARCHITECTURE_PLAYBOOK.md`: design, security and deployment guide for MCP servers.

## Quick start
1. Copy the `.cursorrules` (Cursor) or `CLAUDE.md` (Claude Code) for your stack into your project root.
2. Generate an MCP config: `python mcp-configs/generate_mcp_config.py --client claude --all`
3. Paste the output into your client's config file and restart the client.

- Interactive Builder: https://johannschiffer.github.io/
- Enterprise Suite ($19 USD): https://johanld.gumroad.com/l/genesis-enterprise-suite
