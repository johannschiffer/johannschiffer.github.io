#!/usr/bin/env python3
"""Generate MCP client config for Claude Desktop, Cursor or Windsurf.

Usage:
  python generate_mcp_config.py --client claude --servers crawlengine-mcp pgsafe-mcp
  python generate_mcp_config.py --client cursor --all
"""
import argparse
import json
import sys

OWNER = "johannschiffer"
SERVERS = ["crawlengine-mcp", "browserbridge-mcp", "pgsafe-mcp", "omnibridge-mcp", "sysflow-mcp", "fastmcp-forge"]
PATHS = {
    "claude": "~/.config/Claude/claude_desktop_config.json (Linux), ~/Library/Application Support/Claude/claude_desktop_config.json (macOS)",
    "cursor": ".cursor/mcp.json in your project, or ~/.cursor/mcp.json for all projects",
    "windsurf": "~/.codeium/windsurf/mcp_config.json",
}


def build(servers):
    return {"mcpServers": {s: {"command": "uvx", "args": ["--from", f"git+https://github.com/{OWNER}/{s}", s]} for s in servers}}


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--client", choices=PATHS, required=True)
    p.add_argument("--servers", nargs="*", choices=SERVERS, default=[])
    p.add_argument("--all", action="store_true")
    a = p.parse_args()
    servers = SERVERS if a.all else a.servers
    if not servers:
        p.error("choose --servers or --all")
    print(json.dumps(build(servers), indent=2))
    print(f"\nSave this to: {PATHS[a.client]}", file=sys.stderr)


if __name__ == "__main__":
    main()
